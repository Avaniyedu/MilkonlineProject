from django.apps import AppConfig


class MilkonlineappConfig(AppConfig):
    name = 'MilkonlineApp'
